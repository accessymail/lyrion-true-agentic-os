# Governed Self-Improvement and Evolution

## Core principle

Lyrion may learn and propose improvements, but production authority is not self-granted.

## Separation

```text
Production Lyri
 ↓ telemetry / outcomes
Learning Lab
 ↓ candidate change
Validation
 ↓ security + quality + regression
Change Proposal
 ↓ governance
Human approval when required
 ↓ staged deployment
Monitor
 ↓ promote or rollback
```

## Evolution autonomy levels

- E0 Observe
- E1 Analyze
- E2 Propose
- E3 Validate
- E4 Stage
- E5 Promote only for pre-approved low-risk change classes

## Human-only boundary

Changes affecting identity roots, security roots, authorization, governance, secrets, execution isolation, emergency controls or autonomy ceilings require human authorization.

## Invariant

No production change without a tested rollback path.
