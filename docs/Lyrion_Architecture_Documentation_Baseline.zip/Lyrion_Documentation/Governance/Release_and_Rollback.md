# Release and Rollback

## Deployment pattern

Candidate → isolated validation → canary/stage → monitor → promote or rollback.

## Rollback requirements

Every consequential change must have:

- versioned artifact
- known-good checkpoint
- rollback procedure
- monitoring signals
- rollback authority independent of the evolving component

## Emergency controls

Capability revocation, credential invalidation, network isolation, sandbox termination and deployment suspension must remain enforceable outside the affected AI process.
