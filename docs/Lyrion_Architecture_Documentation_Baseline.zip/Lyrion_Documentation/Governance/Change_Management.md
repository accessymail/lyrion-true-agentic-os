# Change Management

## Change Proposal fields

- proposal ID
- author/generator
- change type
- rationale
- expected benefit
- affected components
- security impact
- privacy impact
- performance impact
- cost impact
- dependencies
- risk classification
- test plan
- evaluation results
- rollback plan
- deployment plan
- monitoring plan
- approval requirements

## Change risk classes

| Class | Example | Governance |
|---|---|---|
| 0 | transient response adaptation | automatic |
| 1 | user preference | user-visible/reversible |
| 2 | low-risk routing/caching optimization | bounded automatic or approved |
| 3 | new agent/skill/model/tool | security + evaluation gate |
| 4 | privilege/security/network changes | human authorization |
| 5 | identity/security-root/governance changes | human authorization + controlled release |
