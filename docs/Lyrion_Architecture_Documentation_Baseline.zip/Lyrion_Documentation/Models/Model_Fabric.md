# Model Fabric

## Execution model

```text
Lyri → AI Gateway → Model Router → Provider Adapter / Execution Target
```

## Targets

- cloud model APIs
- cloud-hosted open models
- cloud GPU workloads
- local CPU models
- local GPU models
- remote sandboxes

## Routing dimensions

Capability, reasoning difficulty, context, modality, privacy, security, latency, cost, availability, reliability, hardware and persona compatibility.
