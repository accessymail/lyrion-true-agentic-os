# Cloud-First and Hybrid Execution

## Initial deployment

Lyrion operates cloud-first. A powerful local GPU is not required.

The local computer primarily provides:

- interface
- voice session
- control
- local integrations
- approved local file access
- credential boundary
- lightweight services

## Future execution modes

- Cloud-only
- Local-only where hardware permits
- Hybrid

The compute target abstraction allows local models and accelerators to be added later without changing PIAE interfaces.
