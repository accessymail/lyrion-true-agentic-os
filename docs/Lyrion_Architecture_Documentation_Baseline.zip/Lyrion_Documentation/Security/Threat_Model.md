# Lyrion Threat Model

## Principal threat classes

- direct prompt injection
- indirect prompt injection
- tool poisoning
- MCP poisoning
- memory poisoning
- knowledge poisoning
- malicious skills
- malicious connectors
- agent impersonation
- tool impersonation
- privilege escalation
- credential theft
- data exfiltration
- malicious dependencies
- unexpected code execution
- compromised model/provider
- compromised external service
- rogue agent behavior
- cascading agent failures
- unsafe autonomous actions

## Security posture

Assume models, external content, tools, skills and external agents can be compromised. Safety should be preserved through independent controls and least privilege rather than through trust in model behavior.
