# Identity and Authorization

## Separation

Human identity, authentication, authorization, agent identity, trust and personalization are distinct concepts.

## Human authentication

Preferred foundation:

- account identity
- passkeys / WebAuthn
- device binding
- cryptographic sessions

Biometric signals may be an additional factor or convenience mechanism, not the sole root of authority.

## Agent identity

Every agent should have an auditable identity, explicit capabilities, policy scope, risk level and lifecycle state.

## Capability authorization

```text
Identity → Capability → Resource → Conditions → Approval → Execution
```
