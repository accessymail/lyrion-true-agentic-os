# Aegis AI Defense & Trust Architecture

## Mission

Aegis is the independent trust, authorization, security and containment plane around Lyri and its agents.

## Core controls

- zero-trust boundaries
- agent identity
- least privilege
- capability-based authorization
- policy-as-code
- context firewall
- tool-output sanitization
- sandboxing
- secrets isolation
- network restrictions
- DLP
- auditability
- runtime anomaly detection
- security evaluation
- incident containment

## Hard rule

The model may request authority but cannot grant itself authority.

## Protected assets

- user identity
- credentials
- personal data
- memory
- world state
- tools
- MCP servers
- agent identities
- execution environments
- governance configuration
- rollback controls
