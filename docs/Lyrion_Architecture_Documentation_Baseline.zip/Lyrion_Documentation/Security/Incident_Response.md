# AI Incident Response

## State machine

```text
NORMAL
 ↓
SUSPICIOUS
 ↓
CONTAINMENT
 ↓
INVESTIGATION
 ↓
QUARANTINE
 ↓
CREDENTIAL REVOCATION / ROTATION
 ↓
SAFE CHECKPOINT / ROLLBACK
 ↓
RE-EVALUATION
 ↓
RESTORE or RETIRE
```

## Independent emergency controls

Emergency stop, capability revocation, credential invalidation, network isolation and sandbox termination must remain enforceable outside the authority of the AI being controlled.
