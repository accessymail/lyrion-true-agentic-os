# Development Workspace and Live Preview

## Future capability

Development tasks run in isolated, versioned workspaces with live build/test previews.

## Workflow

```text
Lyri → Project Plan → Specialist Team → Sandbox Workspace
     → Build/Test → Live Preview → Human Intervention
```

## Controls

Users can pause, resume, cancel, change requirements, inspect artifacts, approve actions and redirect work without necessarily restarting the entire task.
