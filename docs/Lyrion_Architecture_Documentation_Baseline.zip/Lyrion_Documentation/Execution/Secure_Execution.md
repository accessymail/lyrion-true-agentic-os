# Secure Execution Fabric

## Purpose

Provide a controlled environment for code, browser, file, OS and other privileged actions.

## Controls

- sandboxing
- filesystem isolation
- network policy
- resource limits
- credential broker
- process controls
- checkpoints
- rollback
- audit trail
- kill switch

## Rule

Agents operate through capabilities; they do not receive ambient host authority.
