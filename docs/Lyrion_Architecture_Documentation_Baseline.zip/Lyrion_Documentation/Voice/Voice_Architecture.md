# Voice-First Architecture

## First interface

Voice-first, with text/chat as a companion interface.

## Realtime flow

```text
Microphone
 ↓
VAD / acoustic processing
 ↓
Turn detection
 ↓
Streaming ASR or realtime audio model
 ↓
Context + PIAE
 ↓
Cognitive Runtime
 ↓
Streaming response
 ↓
TTS / realtime audio
 ↓
Speaker
```

## Requirements

- low latency
- streaming
- barge-in
- interruption handling
- session continuity
- failure fallback
- provider neutrality
- dedicated voice evaluation
