# Skill Architecture

A skill is a governed capability package, not an untrusted prompt snippet.

## Skill metadata

- identity
- provenance
- version
- dependencies
- tools
- permissions
- risk classification
- evaluation history
- execution requirements

## Lifecycle

Discover → Validate → Scan → Evaluate → Approve → Register → Execute → Monitor → Review → Revoke/Update
