# Agent Runtime

## Architecture

```text
Lyri Executive
 ↓
Agent Manager / Planner
 ↓
Specialist Workers
 ↓
Tools / Skills
 ↓
Verification
```

## Initial workers

Research, retrieval, memory and verification workers. Additional specialists are added when a concrete use case justifies them.

## Lifecycle

REGISTERED → EVALUATED → APPROVED → STAGED → ACTIVE → MONITORED → SUSPENDED/RETIRED
