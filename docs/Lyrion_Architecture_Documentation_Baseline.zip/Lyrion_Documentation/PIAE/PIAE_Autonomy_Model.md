# PIAE Autonomy Model

## Action policy

Autonomy is assigned per capability and task, not globally.

| Level | Default behavior |
|---|---|
| L0 | Observe only |
| L1 | Inform / notify |
| L2 | Prepare / draft |
| L3 | Execute bounded low-risk action |
| L4 | Execute bounded multi-step workflow |
| L5 | Long-running autonomous goal under explicit policy |

## High-risk boundary

Security configuration, credentials, financial actions, destructive operations, identity changes, and governance controls require explicit policy and appropriate human authorization.

## Emergency behavior

Any anomaly may trigger suspension, credential revocation, network isolation, sandbox termination, quarantine and rollback according to policy.
