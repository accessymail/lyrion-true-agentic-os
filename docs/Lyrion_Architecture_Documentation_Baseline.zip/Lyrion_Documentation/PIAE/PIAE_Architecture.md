# PIAE Architecture

## Purpose

PIAE is the first major production subsystem. It decides whether Lyri should notice, suggest, prepare, wait, or act based on context, utility, interruption cost, risk and authorization.

## Core loop

```text
Observe → Normalize → State Update → Context → Opportunity
→ Utility → Interruption Cost → Risk → Permission
→ Autonomy Policy → Decide → Act/Suggest/Wait
→ Verify → Record → Update State/Memory
```

## Autonomy levels

- L0 Observe
- L1 Inform
- L2 Prepare
- L3 Bounded low-risk execution
- L4 Bounded multi-step workflows
- L5 Long-horizon autonomy

## PIAE safeguards

- no implicit authority
- explicit capability scopes
- interruption-cost awareness
- rate/resource budgets
- human approval for high-risk actions
- durable task state
- cancellation and pause support
- verification after consequential actions
