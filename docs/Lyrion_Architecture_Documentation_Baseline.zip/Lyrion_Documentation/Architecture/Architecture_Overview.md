# Architecture Overview

## 1. Platform identity

Lyrion Intelligence OS is a personal intelligence and agentic operating environment. Lyri is its persistent assistant identity. PIAE is the proactive intelligence and autonomy engine. Aegis is the AI defense and trust fabric.

## 2. Architectural layers

1. Interaction Fabric
2. Perception Fabric
3. Event / Context Fabric
4. World-State Fabric
5. PIAE
6. Personality, Cognitive, and Affective/Social Intelligence
7. Memory / Knowledge Fabric
8. Goal / Planning Fabric
9. Agent / Skill Harness
10. Aegis Defense / Governance
11. Capability Gateway
12. Secure Execution Fabric
13. Model / Compute Fabric
14. Observability / Evaluation
15. Learning / Research Plane

## 3. Core invariant

> Intelligence may propose. Policy may authorize. Execution may act. Verification may accept or reject. State records reality. Memory preserves experience.

## 4. Design constraints

- Cloud-first initially; no local GPU requirement.
- Provider/model neutrality.
- Local execution can be added later without redesigning core interfaces.
- Security enforcement must not depend exclusively on model instructions.
- Production execution is separated from learning/evolution.
- High-risk autonomy and evolution remain governed.
