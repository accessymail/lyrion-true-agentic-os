# Lyrion System Blueprint

## 1. End-to-end workflow

```text
Human / Voice / Event
        ↓
Interaction + Perception
        ↓
Event / Context Fabric
        ↓
World-State Update
        ↓
PIAE Opportunity Detection
        ↓
User/Goal/Context Assembly
        ↓
Cognitive Runtime
        ↓
Plan + Tool/Agent Selection
        ↓
Aegis Identity / Capability / Risk / Policy
        ↓
Approval if required
        ↓
Capability Gateway
        ↓
Secure Execution
        ↓
Observation + Verification
        ↓
User Communication
        ↓
Trace / Evaluation
        ↓
State + Memory Update
```

## 2. Trust boundaries

```text
Human
  │ authenticated
  ▼
Lyri session
  │
  ▼
Intelligence plane
  │ request only
  ▼
Governance / Policy plane
  │ authorization
  ▼
Capability gateway
  │ constrained access
  ▼
Sandbox / service / external system
```

## 3. Production vs research

Production is separated from the Learning/Research Plane. Candidate model, policy, skill, agent, routing, or architectural changes are evaluated and staged before promotion.

## 4. Execution target abstraction

```text
ExecutionTarget
 ├── LOCAL_CPU
 ├── LOCAL_GPU
 ├── CLOUD_API
 ├── CLOUD_GPU
 └── REMOTE_SANDBOX
```

The platform routes by capability, privacy, security, latency, cost, availability, context requirements, hardware and approved model compatibility.
