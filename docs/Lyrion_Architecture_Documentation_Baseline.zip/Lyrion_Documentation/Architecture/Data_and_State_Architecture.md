# Data and State Architecture

## 1. World State

World State represents current believed state, not an archive of everything Lyri has ever seen.

Core state domains:

- user
- environment
- device
- system
- agent
- project
- task
- temporal
- security
- deployment
- evaluation
- relationship

## 2. State properties

Every important state record should support:

- provenance
- timestamp
- validity interval
- confidence
- supersession
- relationships
- privacy class
- source

## 3. Memory relationship

```text
Events → Memory candidates → Validated memory
                           ↓
                    World-state reconstruction
```

Memory preserves experience. World State represents current operational truth.

## 4. Personal data separation

Identity, profile/preferences, memory, world-state and security records should use separate logical domains and least-privilege access.
