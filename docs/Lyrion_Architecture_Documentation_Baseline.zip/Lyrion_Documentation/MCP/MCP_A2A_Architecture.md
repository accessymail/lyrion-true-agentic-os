# MCP and A2A Architecture

## MCP

MCP is the external tool/context interoperability layer.

```text
Lyri → Capability Gateway → MCP Trust Gateway → MCP Server → Tool/Resource
```

MCP servers are not trusted by default.

## A2A

A2A is used for interoperability between independent agents when external agent federation is needed.

```text
Lyrion → A2A Gateway → External Agent
```

Internal agent communication can use a simpler strongly typed internal protocol.

## Boundary principle

MCP and A2A remain protocol adapters behind Lyrion's internal capability and trust abstractions.
