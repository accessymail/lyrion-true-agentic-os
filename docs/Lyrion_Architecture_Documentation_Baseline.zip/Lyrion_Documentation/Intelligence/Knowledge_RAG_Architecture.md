# Knowledge and RAG Architecture

## Retrieval fabric

The platform uses a strategy-selecting retrieval fabric rather than a single RAG implementation.

```text
Query
 ↓
Query Understanding
 ↓
Retrieval Planner
 ↓
Lexical / Vector / Structured / Graph / Temporal / Web retrieval
 ↓
Fusion
 ↓
Reranking
 ↓
Evidence Trust
 ↓
Verification
 ↓
Evidence Package
 ↓
Reasoning
```

## Supported strategies

Hybrid RAG, BM25, dense retrieval, sparse retrieval, RRF, reranking, query rewriting/decomposition, contextual compression, temporal retrieval, GraphRAG, knowledge-graph reasoning, multimodal retrieval, SQL retrieval, web retrieval and future agentic/adaptive retrieval.

## Security

Retrieved data is evidence, not automatically trusted instruction.
