# Affective & Social Intelligence

## Purpose

Estimate emotional and social context from available evidence, maintain uncertainty, adapt interaction, and support relationship-aware reasoning.

## Initial scope

- intent recognition
- conversational empathy
- communication adaptation
- basic affective cues from voice/text
- interruption sensitivity
- cognitive-load/context awareness

## Later scope

- multimodal affective inference
- relationship modeling
- social-context reasoning
- Theory of Mind research
- group dynamics
- negotiation
- social consequence reasoning

## Safety rule

Affective inference is probabilistic evidence, never an authorization signal and never automatically a permanent user fact.
