# Memory Architecture

## Memory classes

Working, short-term, episodic, semantic, procedural, associative, conversation, personal, project, event, knowledge, reflective and system memory.

## Memory governance

Each persistent memory item should support provenance, confidence, trust, temporal validity, supersession, privacy classification and validation state.

## Memory lifecycle

```text
Candidate → Validate → Store → Retrieve → Use → Correct / Consolidate → Expire / Decay
```

Persistent memory must not automatically alter identity, authorization, security policy or autonomy ceilings.
