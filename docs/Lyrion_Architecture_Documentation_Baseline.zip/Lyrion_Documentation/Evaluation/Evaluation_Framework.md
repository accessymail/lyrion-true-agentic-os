# Evaluation Framework

## Evaluation domains

- capability
- reasoning
- planning
- memory
- knowledge
- RAG
- tool use
- voice
- multimodal
- safety
- security
- reliability
- latency
- cost
- resource consumption
- personality
- social intelligence
- proactivity
- trajectory integrity

## Trajectory integrity

A task is not considered fully successful if the agent reaches the correct result through an unauthorized, unsafe, disproportionate or policy-violating execution path.

## Continuous evaluation

Important model, skill, agent, policy and architecture changes must be evaluated before promotion.
